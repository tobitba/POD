# ${artifactId}

## Synopsis


## Code Example


## Motivation



## Installation

To package run:

* mvn clean install

## API Reference

Once packaged both server and api project contain a tar.gz with each application and on the root a package a script to run the main classes exists.

## Tests

To run the test

* mvn test

To get the coverage report

* mvn site

## Contributors


## License

