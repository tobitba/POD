package ar.edu.itba.pod.graphql.blog;


import org.springframework.stereotype.Controller;

@Controller
public class AuthorController {

}