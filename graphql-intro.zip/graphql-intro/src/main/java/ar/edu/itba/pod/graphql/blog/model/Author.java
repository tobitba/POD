package ar.edu.itba.pod.graphql.blog.model;

public record Author(String id, String name) {
}
